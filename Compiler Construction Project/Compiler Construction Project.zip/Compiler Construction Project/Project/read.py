def calculate_expression(expression):
    try:
        result = eval(expression)
        return result
    except Exception as e:
        print(f"Error: {e}")
        return None
if __name__ == "__main__":
    print("Simple Calculator using BODMAS rule")
    while True:
        expression = input("Enter a mathematical expression (or 'exit' to quit): ")
        if expression.lower() == 'exit':
            break
        result = calculate_expression(expression)
        if result is not None:
            print(f"Result: {result}")
        else:
            print("Invalid expression. Please enter a valid mathematical expression.")